These files accompany the article
  Charles Bos
  A Bayesian Analysis of Unobserved Component Models using Ox
  Journal of Statistical Software, 41(13), 1-22.
  http://www.jstatsoft.org/v41/i13/

To run the programs, an installation of Ox including SsfPack is needed.
For the graphics, either the full OxMetrics, or an installation of
GnuDraw is required. In the latter case, change all references to
  #include <oxdraw.h>
into
  #include <packages/gnudraw/gnudraw.h>

The programs are split into versions for the nile data (data/nile.mat)
and for the SP500 data (data/sp500.csv). 

For the Nile data, and using the standard local level model,
programs estimating using
  maximum likelihood          estnileml.ox
  Metropolis Hastings         estnilemh.ox
  Gibbs sampling              estnilegb.ox
  particle filtering          estnilepf.ox
are provided. For the model including stochastic volatility, 
  estnilegbsv.ox
uses Gibbs sampling to build a sample from the posterior density. This
posterior sample is used in 
  estnilepfsv.ox
to compute the marginal likelihood using the particle filter.

For the SP500 data, 
  Gibbs sampling              estspgb.ox
  Gibbs sampling with sv      estspgbsv.ox
  particle filtering with sv  estsppfsv.ox
are provided. 

Note that the programs are provided as-is. They have been checked
thoroughly, but there is no guarantee that they are without flaw.

Amsterdam, 15 April 2011
Charles Bos
c.s.bos@vu.nl

